
// get data      
var key = 'AIzaSyA2jRvS1F2HOJrwCfV_Wd_E0GC2l7ImnFs';
    
var spreadsheetID = "1DlfO9U5jPQWgL9edzvTKLsXRAPX1EmRvxyJnoYmPJvc";
  //var url = "https://sheets.googleapis.com/v4/spreadsheets/1DlfO9U5jPQWgL9edzvTKLsXRAPX1EmRvxyJnoYmPJvc/values:batchGet?ranges=Lists!A1:J32&majorDimension=COLUMNS&key=AIzaSyA2jRvS1F2HOJrwCfV_Wd_E0GC2l7ImnFs";
  //var url = "https://sheets.googleapis.com/v4/spreadsheets/1DlfO9U5jPQWgL9edzvTKLsXRAPX1EmRvxyJnoYmPJvc/values:batchGet?ranges=Lists!A1:J32&majorDimension=ROWS&key=AIzaSyA2jRvS1F2HOJrwCfV_Wd_E0GC2l7ImnFs";
  
  var url = "https://sheets.googleapis.com/v4/spreadsheets/1DlfO9U5jPQWgL9edzvTKLsXRAPX1EmRvxyJnoYmPJvc/values:batchGet?ranges=Data%20source!B1:J90&majorDimension=ROWS&key=AIzaSyA2jRvS1F2HOJrwCfV_Wd_E0GC2l7ImnFs";
  
// and remember the jqXHR object for this request
var chaindata = ''; 


$( document ).ready(function() {

    var jqxhr = $.get(url)
  
      .done(function(data) {
        // alert( "success" );
        // console.log(data);
        // console.log(data.valueRanges[0].values);
        data = data.valueRanges[0].values;
        console.log(data[0]);
        getJsonArrayFromData(data)
        // var chaindata = data.valueRanges[0].values;
      })
      .fail(function() {
        alert( "error" );
      })
      .always(function() {
        // alert( "complete" );
      });
    });
function getJsonArrayFromData(data)
{
    
  var obj = {};
  var result = [];
  var headers = data[0];
  var cols = headers.length;
  var row = [];

  for (var i = 1, l = data.length; i < l; i++)
  {
    // get a row to fill the object
    row = data[i];
    // clear object
    obj = {};
    for (var col = 0; col < cols; col++) 
    {
      // fill object with new values
      obj[headers[col]] = row[col];    
    }
    // add object in a final result
    result.push(obj);  
  }
  console.log(result);
  var str = JSON.stringify(result, undefined, 9); // spacing level = 2
//   $('div.sheet').html(str);
    // output(str);
    output(syntaxHighlight(str));
    // var obj = {a:1, 'b':'foo', c:[false,'false',null, 'null', {d:{e:1.3e5,f:'1.3e5'}}]};
    // var str = JSON.stringify(obj, undefined, 4);
  return result;  

}
function output(inp) {
    document.body.appendChild(document.createElement('pre')).innerHTML = inp;
}

function syntaxHighlight(json) {
    json = json.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    return json.replace(/("(\\u[a-zA-Z0-9]{4}|\\[^u]|[^\\"])*"(\s*:)?|\b(true|false|null)\b|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)/g, function (match) {
        var cls = 'number';
        if (/^"/.test(match)) {
            if (/:$/.test(match)) {
                cls = 'key';
            } else {
                cls = 'string';
            }
        } else if (/true|false/.test(match)) {
            cls = 'boolean';
        } else if (/null/.test(match)) {
            cls = 'null';
        }
        return '<span class="' + cls + '">' + match + '</span>';
    });
}




